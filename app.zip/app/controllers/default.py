from flask import request, jsonify, render_template
from app import app
import RPi.GPIO as gpio
import time as delay
import threading
import requests
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import smtplib

# Configuração dos pinos GPIO
gpio.setmode(gpio.BOARD)
gpio.setwarnings(False)

pin_t = 15  
pin_e = 16  
lixeira_v = 20  
led_vermelho, led_verde = 11, 12
gpio.setup(pin_t, gpio.OUT)        # Trigger como saída
gpio.setup(pin_e, gpio.IN)         # Echo como entrada
gpio.setup(led_verde, gpio.OUT)    # LED verde como saída
gpio.setup(led_vermelho, gpio.OUT) # LED vermelho como saída

# Configurações do ThingSpeak
THINGSPEAK_API_KEY = '64UO42N3UWFWESGW'
THINGSPEAK_URL = 'https://api.thingspeak.com/update'

# Variáveis globais
ocupacao = 0
estado_tampa = 'fechada'
contador_aberturas = 0
historico = []
email_notificacao = None

# Função para calcular a distância
def distancia():
    gpio.output(pin_t, True)
    delay.sleep(0.00001)
    gpio.output(pin_t, False)
    
    tempo_i = delay.time()
    tempo_f = delay.time()

    while gpio.input(pin_e) == False:
        tempo_i = delay.time()
    while gpio.input(pin_e) == True:
        tempo_f = delay.time()
    
    temp_d = tempo_f - tempo_i

    # Calcula a distância em cm
    distancia = (temp_d * 34300) / 2
    return distancia

# Função para determinar o nível de ocupação da lixeira
def nivel_ocupacao(dist):
    if dist >= lixeira_v:
        return "vazia"  
    elif dist < 5:
        return "cheia"  
    else:
        ocupacao = ((lixeira_v - dist) / lixeira_v) * 100
        return f"{ocupacao:.1f}% ocupada"

def controlar_leds():
    dist = distancia()
    
    if dist >= lixeira_v:  # Lixeira vazia
        gpio.output(led_verde, True)
        gpio.output(led_vermelho, False)
    elif dist < lixeira_v:  # Lixeira não está vazia (cheia ou parcialmente ocupada)
        gpio.output(led_verde, False)
        # Faz o LED vermelho piscar 3 vezes
        for _ in range(3):
            gpio.output(led_vermelho, True)
            delay.sleep(0.5)
            gpio.output(led_vermelho, False)
            delay.sleep(0.5)
    else:
        # Caso inesperado, apaga todos os LEDs
        gpio.output(led_verde, False)
        gpio.output(led_vermelho, False)

# Função para piscar os LEDs
def piscar_led(led, vezes):
    for _ in range(vezes):
        gpio.output(led, True)
        delay.sleep(0.3)
        gpio.output(led, False)
        delay.sleep(0.3)

# Função para atualizar o nível de ocupação
def atualizar_ocupacao():
    while True:
        distancia_medida = distancia()
        ocupacao = max(0, round((lixeira_v - distancia_medida) / lixeira_v * 100))
        controlar_leds()
        try:
            requests.post(
                THINGSPEAK_URL,
                data={'api_key': THINGSPEAK_API_KEY, 'field1': ocupacao}
            )
        except Exception as e:
            print(f"Erro ao enviar para o ThingSpeak: {e}")
        delay.sleep(30)

# Função para enviar alerta por e-mail
def enviar_email_alerta(mensagem):
    if not email_notificacao:
        print("Nenhum e-mail configurado para envio.")
        return

    remetente = "email@email.com"
    senha = "senha_email"
    msg = MIMEMultipart()
    msg['From'] = remetente
    msg['To'] = email_notificacao
    msg['Subject'] = "⚠️ Alerta: Lixeira Quase Cheia ⚠️"

    # Corpo do e-mail
    mensagem = f"""
    Olá,

    A lixeira atingiu {ocupacao}% de ocupação e está quase cheia. 

    Por favor, providencie o esvaziamento o quanto antes para evitar transtornos.

    Atenciosamente,
    Lixeira Inteligente da aula de IoT.
    """
    msg.attach(MIMEText(mensagem, 'plain'))

    try:
        with smtplib.SMTP('smtp.gmail.com', 587) as servidor:
            servidor.starttls()
            servidor.login(remetente, senha)
            servidor.send_message(msg)
            print("E-mail enviado com sucesso!")
    except Exception as e:
        print(f"Erro ao enviar e-mail: {e}")

# Rotas do Flask
@app.route("/")
def home():
    templateData = {
        'distancia': distancia(),
        'nivel_ocupacao': nivel_ocupacao(distancia()),  # Corrigido para usar a função nivel_ocupacao
        'ocup_lixeira': distancia()
    }
    return render_template("index.html", **templateData)

@app.route('/abrir-lixeira', methods=['POST'])
def abrir_lixeira():
    global estado_tampa, contador_aberturas
    estado_tampa = 'aberta'
    contador_aberturas += 1
    historico.append({'evento': 'Lixeira aberta', 'data': delay.strftime("%Y-%m-%d %H:%M:%S")})
    if ocupacao >= 90 and email_notificacao:
        enviar_email_alerta(f"A lixeira atingiu {ocupacao}% de ocupação! Verifique.")
    return jsonify({'status': 'ok', 'estado': estado_tampa})

@app.route('/fechar-lixeira', methods=['POST'])
def fechar_lixeira():
    global estado_tampa
    estado_tampa = 'fechada'
    historico.append({'evento': 'Lixeira fechada', 'data': delay.strftime("%Y-%m-%d %H:%M:%S")})
    return jsonify({'status': 'ok', 'estado': estado_tampa})

@app.route('/historico', methods=['GET'])
def obter_historico():
    return jsonify(historico)

@app.route('/ocupacao', methods=['GET'])
def obter_ocupacao():
    return jsonify({'ocupacao': ocupacao, 'estado_tampa': estado_tampa})

@app.route('/configurar-email', methods=['POST'])
def configurar_email():
    global email_notificacao
    dados = request.json
    email_notificacao = dados.get('email')
    return jsonify({'mensagem': 'E-mail configurado com sucesso!'})

@app.route("/led_vermelho/<action>")
def led_vermelho(action):
    if action == 'on':
        gpio.output(led_vermelho, gpio.HIGH)
    elif action == 'off':
        gpio.output(led_vermelho, gpio.LOW)
    
    templateData = {
        'ledRed': "Ligado" if gpio.input(led_vermelho) else "Desligado",
        'ledGreen': "Ligado" if gpio.input(led_verde) else "Desligado"
    }
    return render_template('index.html',**templateData)

@app.route("/led_verde/<action>")
def led_verde(action):
    if action == 'on':
        gpio.output(led_verde, gpio.HIGH)
    elif action == 'off':
        gpio.output(led_verde, gpio.LOW)
    
    templateData = {
        'ledRed': "Ligado" if gpio.input(led_vermelho) else "Desligado",
        'ledGreen': "Ligado" if gpio.input(led_verde) else "Desligado"
    }
    return render_template('index.html',**templateData)


# Inicializa a thread de ocupação
thread = threading.Thread(target=atualizar_ocupacao)
thread.daemon = True
thread.start()